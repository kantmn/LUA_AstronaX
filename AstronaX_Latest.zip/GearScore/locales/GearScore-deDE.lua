local AceLocale = LibStub:GetLibrary("AceLocale-3.0")
local L = AceLocale:NewLocale("GearScore", "deDE", true)
if not L then return end

	L["Human"] = "Mensch"
	L["Dwarf"] = "Zwerg"
	L["Gnome"] = "Gnome"
	L["BloodElf"] = "Blutelf"
	L["NightElf"] = "Nachtelf"
	L["Orc"] = "Ork"
	L["Tauren"] = "Taure"
	L["Troll"] = "Troll"
	L["Draenei"] = "Draenei"
	L["Undead"] = "Untoter"
	L["Warrior"] = "Krieger"
	L["Death Knight"] = "Todesritter"
	L["Paladin"] = "Paladin"
	L["Shaman"] = "Schamane"
	L["Hunter"] = "Jäger"
	L["Druid"] = "Druide"
	L["Rogue"] = "Schurke"
	L["Warlock"] = "Hexenmeister"
	L["Priest"] = "Priester"
	L["Mage"] = "Magier"
